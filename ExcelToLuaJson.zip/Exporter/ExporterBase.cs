﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ExcelExport.Exporter
{
    public class ExporterBase
    {

        protected virtual void ExportTiny(ExcelSheetData data,StreamWriter writer)
        {
            //nothing
        }

        protected virtual void ExportBase(ExcelSheetData data,StreamWriter writer)
        {
            //nothing
        }


        protected virtual void AddHeader(ExcelSheetData data, StreamWriter writer)
        {
            writer.WriteLine(data.exportHeader);
        }

        protected virtual void AddEnd(ExcelSheetData data, StreamWriter writer)
        {
            writer.WriteLine(data.exportEnd, writer);
        }

        //子类只需按情况实现上面4个函数。

        public void SaveToFile(ExcelSheetData data , string fileName)
        {

            var stream = new FileStream(fileName, FileMode.Create);
            var writer = new StreamWriter(stream);

            if (data.exportSchema == "base")
            {
                ExportTiny(data, writer);
            } else if(data.exportSchema == "tiny")
            {
                ExportTiny(data, writer);
            }

            writer.Close();
            stream.Close();

        }

    }
}
