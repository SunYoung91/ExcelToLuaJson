﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;

namespace ExcelExport
{
    public class ExcelTableData
    {
        private List<ExcelSheetData> excelSheets = new List<ExcelSheetData>();

        public void LoadFromFile(string fileName)
        {
            var stream = File.Open(fileName, FileMode.Open, FileAccess.Read);
            var reader = ExcelReaderFactory.CreateReader(stream);         
            for (int i = 0; i < reader.ResultsCount; i++)
            {            
                var sheet = new ExcelSheetData();
                sheet.ReadFromExcel(reader.Name, reader);
                reader.NextResult();
            }

            stream.Close();
        }
    }
}
